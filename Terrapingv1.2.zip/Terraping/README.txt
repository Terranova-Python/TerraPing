Ping Monitor Tool
Author: Terranovatech
Version: 1.2

Description
The Ping Monitor Tool is a Python-based application with a GUI built using Tkinter. It monitors internet connectivity by periodically pinging a target address (8.8.8.8). If internet access is lost, it pings a user-specified list of IP addresses to help identify potential issues in the local network or external infrastructure.

Features
Dynamic IP Management: Add and remove IP addresses directly through the GUI.
Interval Selection: Choose from 1-minute, 5-minute, or 10-minute monitoring intervals.
Real-Time Logging: Logs results in a scrollable GUI and saves them to ping_log.txt.
Tracerouting: Enable Traceroute on failed Pings after an internet outage.
Responsive GUI: Background monitoring ensures the application remains responsive.